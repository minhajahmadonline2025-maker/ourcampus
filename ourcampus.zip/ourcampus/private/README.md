# PRIVATE — do not commit or upload

`accounts.csv` holds the starting sign-in accounts and passwords.
Create them in Supabase with:

    npm run accounts:create -- private/accounts.csv

Then share each person's Campus ID + password privately and ask them to change it (Profile & Settings).
